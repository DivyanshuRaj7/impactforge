import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const NeedCard = ({ title, description, urgent, initialTimeSeconds, onClick, isRescued, frozenBurnIntensity }) => {
  const [timeLeft, setTimeLeft] = useState(initialTimeSeconds);
  
  useEffect(() => {
    if (timeLeft <= 0 || isRescued) return;
    const interval = setInterval(() => setTimeLeft(t => t - 1), 1000);
    return () => clearInterval(interval);
  }, [timeLeft, isRescued]);

  // Format time
  const hours = Math.floor(timeLeft / 3600);
  const minutes = Math.floor((timeLeft % 3600) / 60);
  const seconds = timeLeft % 60;
  
  // Calculate singe effect (fading boundary) based on percentage left
  const percentageLeft = Math.max(0, timeLeft / initialTimeSeconds);
  const burnIntensity = isRescued ? frozenBurnIntensity : (1 - percentageLeft); // 0 (start) to 1 (done)
  const rotateDeg = (Math.random() * 3) - 1.5;
  return (
    <motion.div 
      layoutId={title}
      onClick={() => onClick && onClick(timeLeft, burnIntensity)}
      className={`relative p-6 pb-12 notebook-paper shadow-soft torn-edge overflow-hidden group transition-all duration-1000 origin-center ${onClick ? 'cursor-pointer hover:border-ink/20' : ''}`}
      style={{ 
        rotate: `${rotateDeg}deg`,
          scale: burnIntensity > 0.6 ? 1 - ((burnIntensity - 0.6) * 0.1) : 1, 
          ...(urgent ? { 
             boxShadow: isRescued 
                ? 'inset 0 0 50px rgba(0,0,0,0.9), inset 10px 10px 100px rgba(10,10,10,0.9), inset -10px -10px 100px rgba(10,10,10,0.9)'
                : 'inset 0 0 50px rgba(0,0,0,0.9), inset 10px 10px 100px rgba(40,15,0,0.8), inset -10px -10px 100px rgba(40,15,0,0.8)' 
          } : {}),
          opacity: burnIntensity > 0.9 ? 1 - ((burnIntensity - 0.9) * 8) : 1,
          filter: `drop-shadow(3px 8px 16px rgba(0,0,0,0.2)) ${
            burnIntensity > 0.2 
              ? isRescued 
                ? `brightness(0.85)`
                : `contrast(${1 + burnIntensity * 1.5}) sepia(${burnIntensity}) brightness(${1 - burnIntensity * 0.3}) saturate(${1 + burnIntensity})`
              : ''
          }`
        }}
      >
        <svg width="0" height="0" className="absolute pointer-events-none">
          <defs>
            <filter id="ink-bleed-gooey">
              <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="blur" />
              <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 20 -9" result="goo" />
              <feComposite in="SourceGraphic" in2="goo" operator="atop" />
            </filter>
          </defs>
        </svg>

        {/* Vicseral Crumbling & Charring Burn Overlay */}
        <div 
          className="absolute inset-0 pointer-events-none transition-all duration-[2s] z-20"
          style={{
            boxShadow: `
              inset 0 0 ${burnIntensity * 30}px ${burnIntensity * 10}px rgba(0, 0, 0, ${burnIntensity * 1.5}), 
              inset 0 0 ${burnIntensity * 120}px ${burnIntensity * 40}px rgba(${isRescued ? '35, 18, 8' : '60, 15, 0'}, ${burnIntensity * 1.2}),
              inset 0 0 ${burnIntensity * 250}px ${burnIntensity * 100}px rgba(${isRescued ? '20, 8, 4' : '120, 40, 0'}, ${burnIntensity * 0.8})
            `,
            mixBlendMode: 'multiply',
          // Freeze the erratic crumbling if rescued, leaving the frozen scars
          filter: (burnIntensity > 0.3 && !isRescued) ? 'url(#crumble-burn)' : 'none'
        }}
      />

      <div className="relative flex flex-col justify-between h-full z-10 pointer-events-none">
        
        {/* Text Body - Gets grayed out on lock */}
        <div className={`transition-all duration-1000 ${isRescued ? 'opacity-40' : ''}`}>
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-xl font-serif text-ink tracking-tight">{title}</h3>
            {urgent && <span className="bg-terracotta/20 text-terracotta text-xs px-2 py-1 rounded font-bold uppercase tracking-wider">Urgent</span>}
          </div>
          
          <p className="text-sm text-ink-light leading-relaxed mb-6">
            {description}
          </p>
        </div>
        
        {/* Footer - Label gets grayed out, Seal stays vibrant */}
        <div className="mt-4 pt-4 border-t border-ink/5 flex items-center justify-between min-h-[40px]">
          <span className={`text-xs uppercase tracking-widest font-medium transition-all duration-1000 ${isRescued ? 'text-ink/30' : 'text-ink/40'}`}>
            {isRescued ? 'Status' : 'Time Remaining'}
          </span>
          <div className="relative flex items-center justify-end w-32 h-8">
            <AnimatePresence mode="popLayout">
              {isRescued ? (
                <motion.div 
                  key="seal"
                  initial={{ scale: 6, opacity: 0, rotate: -60 }}
                  animate={{ scale: 1.2, opacity: 1, rotate: Math.random() * 20 - 10 }}
                  transition={{ type: "spring", stiffness: 300, damping: 10 }}
                  className="absolute right-0 top-1/2 -mt-6 z-30"
                  style={{ filter: "drop-shadow(0 8px 12px rgba(0, 0, 0, 0.5))" }}
                >
                  <svg width="60" height="60" viewBox="0 0 100 100">
                    <defs>
                      <radialGradient id="waxGloss" cx="35%" cy="35%" r="65%">
                         <stop offset="0%" stopColor="#e82020" />
                         <stop offset="50%" stopColor="#a00808" />
                         <stop offset="100%" stopColor="#4a0000" />
                      </radialGradient>
                      <filter id="internal-emboss">
                         <feOffset dx="0" dy="2" />
                         <feGaussianBlur stdDeviation="1" result="offset-blur" />
                         <feComposite operator="out" in="SourceGraphic" in2="offset-blur" result="inverse" />
                         <feFlood floodColor="black" floodOpacity="0.8" result="color" />
                         <feComposite operator="in" in="color" in2="inverse" result="shadow" />
                         <feComposite operator="over" in="shadow" in2="SourceGraphic" />
                      </filter>
                    </defs>
                    {/* Organic, pooling edge bleed */}
                    <circle cx="50" cy="50" r="47" fill="#500000" style={{ filter: 'url(#crumble-burn)' }} />
                    {/* Wax body with specular highlight */}
                    <circle cx="50" cy="50" r="44" fill="url(#waxGloss)" />
                    {/* Stamped inner ridge to simulate the physical metal press */}
                    <circle cx="50" cy="50" r="34" fill="#800404" stroke="#400000" strokeWidth="2" filter="url(#internal-emboss)" />
                    {/* The deeply embossed Ecosystem Crest */}
                    <path d="M50 25 L55 40 L70 42 L58 52 L62 68 L50 58 L38 68 L42 52 L30 42 L45 40 Z" fill="#6a0000" stroke="#3a0000" strokeWidth="1.5" filter="url(#internal-emboss)" />
                  </svg>
                </motion.div>
              ) : (
                <motion.div 
                  key="clock"
                  exit={{ scale: 0.2, filter: "url(#ink-bleed-gooey) brightness(0) blur(4px)", y: 15 }}
                  transition={{ duration: 0.7, ease: "easeInOut" }}
                  className={`font-mono font-medium absolute right-0 ${timeLeft < 3600 ? 'text-terracotta' : 'text-ink'}`}
                >
                  {hours.toString().padStart(2, '0')}:{minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default NeedCard;
