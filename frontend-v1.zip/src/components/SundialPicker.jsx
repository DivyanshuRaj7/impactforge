import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';

// Basic utility to convert polar angles to Cartesian SVG coordinates
const polarToCartesian = (cx, cy, radius, angleInDegrees) => {
  const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
  return { x: cx + (radius * Math.cos(angleInRadians)), y: cy + (radius * Math.sin(angleInRadians)) };
};

const describeArc = (cx, cy, radius, startAngle, endAngle) => {
    // If the path completes a full circle, we can't use an arc, so we constrain
    if (endAngle - startAngle === 360) endAngle = startAngle + 359.99;
    const start = polarToCartesian(cx, cy, radius, endAngle);
    const end = polarToCartesian(cx, cy, radius, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
    return ["M", start.x, start.y, "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y].join(" ");
};

const SundialPicker = ({ colorClass = 'stroke-sage', onSave }) => {
  const svgRef = useRef(null);
  const [segments, setSegments] = useState([]);
  const [dragStart, setDragStart] = useState(null);
  const [dragEnd, setDragEnd] = useState(null);

  const getAngleFromEvent = (e) => {
    if (!svgRef.current) return 0;
    const rect = svgRef.current.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    // support touch or mouse
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    
    let angle = Math.atan2(clientY - cy, clientX - cx) * 180 / Math.PI + 90;
    if (angle < 0) angle += 360;
    return angle; // 0 is top (12 AM), runs clockwise to 360
  };

  const handlePointerDown = (e) => {
    const angle = getAngleFromEvent(e);
    setDragStart(angle);
    setDragEnd(angle);
    if (navigator.vibrate) navigator.vibrate(10); // Haptic starting point
  };

  const handlePointerMove = (e) => {
    if (dragStart === null) return;
    setDragEnd(getAngleFromEvent(e));
  };

  const handlePointerUp = () => {
    if (dragStart !== null && dragEnd !== null) {
      let start = Math.min(dragStart, dragEnd);
      let end = Math.max(dragStart, dragEnd);
      // Ensure the painted segment is valid and wide enough to record
      if (end - start > 5) {
        setSegments([...segments, { start, end }]);
      }
    }
    setDragStart(null);
    setDragEnd(null);
  };

  const formatAngleToTime = (angle) => {
    const totalMinutes = (angle / 360) * 24 * 60;
    let h = Math.floor(totalMinutes / 60);
    const m = Math.floor(totalMinutes % 60);
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12;
    if (h === 0) h = 12;
    return `${h}:${m.toString().padStart(2, '0')} ${ampm}`;
  };

  return (
    <div className="w-full flex flex-col items-center">
      <h3 className="font-serif text-2xl text-ink tracking-tight mb-2">Paint Your Availability</h3>
      <p className="text-sm text-ink-light mb-8 text-center max-w-xs">Drag along the sundial tracker to highlight the hours you are active.</p>
      
      <div className="relative w-80 h-80 touch-none">
        {/* Render 24-hr dial ticks strictly for aesthetics */}
        <div className="absolute inset-0 pointer-events-none opacity-10">
          {[...Array(24)].map((_, i) => (
            <div key={i} className="absolute left-1/2 bottom-1/2 w-0.5 h-full origin-bottom" style={{ transform: `rotate(${i * 15}deg)` }}>
              <div className="w-full h-3 bg-ink" />
            </div>
          ))}
        </div>

        <svg 
          ref={svgRef}
          viewBox="0 0 200 200" 
          className="w-full h-full cursor-pointer overflow-visible drop-shadow-md"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
        >
          {/* Base rail */}
          <circle cx="100" cy="100" r="80" fill="none" stroke="currentColor" strokeWidth="8" className="text-ink/10" />

          {/* Radial Hour Labels mapped via polar Cartesian */}
          {[
             {a: 0, l: '12A'}, {a: 45, l: '3A'}, {a: 90, l: '6A'}, {a: 135, l: '9A'},
             {a: 180, l: '12P'}, {a: 225, l: '3P'}, {a: 270, l: '6P'}, {a: 315, l: '9P'}
          ].map(point => {
             const coords = polarToCartesian(100, 100, 55, point.a);
             return (
               <text key={point.a} x={coords.x} y={coords.y} dominantBaseline="middle" textAnchor="middle" className="text-[9px] font-mono fill-ink/30 tracking-tighter pointer-events-none">
                 {point.l}
               </text>
             );
          })}

          {/* Committed Painted Segments */}
          {segments.map((seg, i) => (
            <motion.path 
              key={i}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              d={describeArc(100, 100, 80, seg.start, seg.end)}
              fill="none"
              strokeLinecap="round"
              strokeWidth="14"
              className={`${colorClass}`}
              style={{ filter: "url(#crumble-burn)" }}
            />
          ))}

          {/* Active Dragging Segment with Attached Brush */}
          {dragStart !== null && (
            <>
              <path
                d={describeArc(100, 100, 80, Math.min(dragStart, dragEnd), Math.max(dragStart, dragEnd))}
                fill="none"
                strokeLinecap="round"
                strokeWidth="14"
                className={`${colorClass} opacity-90`}
                style={{ filter: "url(#crumble-burn)" }}
              />
              {/* Tracker Paintbrush overlay fixed dynamically to dragEnd coordinate */}
              <g transform={`translate(${polarToCartesian(100, 100, 80, dragEnd).x - 12}, ${polarToCartesian(100, 100, 80, dragEnd).y - 25}) rotate(${dragEnd + 45})`} className="pointer-events-none drop-shadow-lg">
                <path d="M12,5 Q18,10 15,25 Q13,35 12,45 Q11,35 9,25 Q6,10 12,5 Z" fill="#4a3b32" />
                <path d="M12,45 Q7,55 12,65 Q17,55 12,45 Z" fill="#111" />
              </g>
            </>
          )}
        </svg>

        {/* Center label readout of active or dragged bounds */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none gap-1">
          {dragStart !== null ? (
            <>
              <span className="text-xs text-ink-light uppercase tracking-widest border border-ink/10 rounded-full px-2 py-0.5 mb-1 bg-paper/50">Painting</span>
              <span className="text-sm font-medium text-ink bg-paper/50 rounded-sm">{formatAngleToTime(Math.min(dragStart, dragEnd))}</span>
              <span className="text-[10px] text-ink-light uppercase bg-paper/50 rounded-sm">to</span>
              <span className="text-sm font-medium text-ink bg-paper/50 rounded-sm">{formatAngleToTime(Math.max(dragStart, dragEnd))}</span>
            </>
          ) : (
            <span className="text-ink font-serif text-lg bg-paper/50 rounded-sm shadow-sm px-2 py-1">{segments.length} Blocks</span>
          )}
        </div>
      </div>
      
      <button 
        onClick={() => onSave(segments)}
        className={`mt-12 px-8 py-3 rounded-full bg-paper text-ink shadow-soft torn-edge font-medium uppercase tracking-widest text-sm hover:-translate-y-1 transition-transform`}
      >
        Confirm Schedule
      </button>
    </div>
  );
};

export default SundialPicker;
