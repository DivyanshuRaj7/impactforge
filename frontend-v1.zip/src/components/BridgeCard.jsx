import React from 'react';
import { Map, ArrowRight } from 'lucide-react';

const BridgeCard = ({ from, to, item, estimatedTime }) => {
  const rotateDeg = (Math.random() * 2) - 1;

  return (
    <div 
      className="relative p-6 bg-[#eae4d3] torn-edge overflow-hidden transition-transform hover:-translate-y-1 block"
      style={{ 
        rotate: `${rotateDeg}deg`,
        filter: 'drop-shadow(3px 8px 16px rgba(0,0,0,0.2))'
      }}
    >
      {/* Subtle Map SVG Background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none mix-blend-multiply">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
          <path d="M10,10 Q30,20 50,10 T90,10 M10,30 Q30,40 50,30 T90,30 M10,50 Q30,60 50,50 T90,50" stroke="currentColor" fill="none" strokeWidth="1" strokeDasharray="2,2"/>
        </svg>
      </div>

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <span className="bg-indigo/20 text-indigo text-xs px-2 py-1 rounded font-medium uppercase tracking-wider">Logistics</span>
          <Map className="w-5 h-5 text-indigo/60" />
        </div>
        
        <h3 className="text-xl font-serif text-ink tracking-tight mb-4">{item}</h3>
        
        <div className="flex items-center gap-3 text-sm font-medium text-ink-light bg-paper/50 p-3 rounded-lg backdrop-blur-sm">
          <div className="flex-1 truncate">{from}</div>
          <ArrowRight className="w-4 h-4 text-indigo flex-shrink-0" />
          <div className="flex-1 truncate text-right">{to}</div>
        </div>
        
        <div className="mt-4 pt-4 border-t border-indigo/10 flex items-center justify-between">
          <span className="text-xs uppercase tracking-widest text-ink/50 font-medium">Est. Journey</span>
          <span className="font-mono text-sm text-indigo font-bold">{estimatedTime}</span>
        </div>
      </div>
    </div>
  );
};

export default BridgeCard;
