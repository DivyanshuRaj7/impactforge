import React, { useState } from 'react';
import { LogOut } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import InkTrapFilters from './InkTrapFilters';
import DiscoveryMatrix from './DiscoveryMatrix';
import DonationCard from './DonationCard';
import FloatingAction from './FloatingAction';
import SundialPicker from './SundialPicker';
import ExpandedCardOverlay from './ExpandedCardOverlay';

const MOCK_DONATIONS = [
  { id: 1, category: 'study', title: 'Engineering Textbooks', imgUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?q=80&w=600&auto=format&fit=crop' },
  { id: 2, category: 'food', title: 'Canned Goods Bundle', imgUrl: 'https://images.unsplash.com/photo-1599557342898-75fcc65cded6?q=80&w=600&auto=format&fit=crop' },
  { id: 3, category: 'medical', title: 'First Aid Kits (Sealed)', imgUrl: 'https://images.unsplash.com/photo-1603398938378-e54eab446dde?q=80&w=600&auto=format&fit=crop' },
  { id: 4, category: 'clothes', title: 'Assorted Winter Jackets', imgUrl: 'https://images.unsplash.com/photo-1551028719-00105bahalf?q=80&w=600&auto=format&fit=crop' },
];

const SeekerDashboard = ({ onReset }) => {
  const [activeFilter, setActiveFilter] = useState('all');
  const [flowState, setFlowState] = useState(null);
  const [expandedCardId, setExpandedCardId] = useState(null);

  const filteredDonations = activeFilter === 'all' 
    ? MOCK_DONATIONS 
    : MOCK_DONATIONS.filter(item => item.category === activeFilter);

  const expandedItem = MOCK_DONATIONS.find(i => i.id === expandedCardId);

  return (
    <div className="flex flex-col min-h-screen relative isolate">
      <div className="sticky top-0 z-50 bg-paper/80 backdrop-blur-md border-b border-terracotta/20 px-8 py-4 flex items-center justify-between">
        <h2 className="text-2xl font-serif text-terracotta tracking-tight">Available Resources</h2>
        <button onClick={onReset} className="flex items-center gap-2 text-ink-light hover:text-ink transition-colors">
          <span className="text-sm uppercase tracking-widest font-medium">Reset Identity</span>
          <LogOut className="w-4 h-4" />
        </button>
      </div>
      
      <InkTrapFilters activeFilter={activeFilter} onFilterChange={setActiveFilter} />
      
      <div className="flex-1 overflow-y-auto px-4 md:px-8 pb-32">
        <DiscoveryMatrix 
          items={filteredDonations} 
          renderSubComponent={(item) => (
            <DonationCard 
               title={item.title} 
               category={item.category} 
               imgUrl={item.imgUrl} 
               onClick={() => setExpandedCardId(item.id)}
            />
          )}
        />
      </div>

      {/* Seeker Post Flow (Goes straight to Sundial for pickup availability) */}
      <FloatingAction colorClass="bg-terracotta" onClick={() => setFlowState('sundial')} />

      <AnimatePresence>
        {flowState === 'sundial' && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-paper/90 backdrop-blur-md flex items-center justify-center p-8"
          >
            <div className="absolute top-8 right-8">
               <button onClick={() => setFlowState(null)} className="text-ink-light tracking-widest text-sm uppercase">Close</button>
            </div>
            <SundialPicker colorClass="stroke-terracotta" onSave={() => setFlowState(null)} />
          </motion.div>
        )}

        {expandedItem && (
          <ExpandedCardOverlay 
            key="expandedItem"
            layoutId={expandedItem.title}
            item={expandedItem}
            onClose={() => setExpandedCardId(null)}
            actionLabel="Request Item"
            colorClass="bg-terracotta"
            title={expandedItem.title}
            category={expandedItem.category}
            description="High quality resource volunteered by verified donor."
            imgUrl={expandedItem.imgUrl}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default SeekerDashboard;
