import React from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';

const FloatingAction = ({ onClick, colorClass }) => {
  return (
    <motion.button
      whileHover={{ scale: 1.1, rotate: 90 }}
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      className={`fixed bottom-8 right-8 z-[60] w-16 h-16 rounded-full shadow-xl flex items-center justify-center text-paper mix-blend-multiply ${colorClass}`}
      style={{ filter: "url(#torn-edge-filter)" }} // Faint jagged tear on the edges of the ink drop
    >
      <Plus className="w-8 h-8" />
    </motion.button>
  );
};

export default FloatingAction;
