import React, { useState } from 'react';
import { LogOut } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import InkTrapFilters from './InkTrapFilters';
import DiscoveryMatrix from './DiscoveryMatrix';
import NeedCard from './NeedCard';
import FloatingAction from './FloatingAction';
import WatercolorCamera from './WatercolorCamera';
import SundialPicker from './SundialPicker';
import ExpandedCardOverlay from './ExpandedCardOverlay';

const MOCK_NEEDS = [
  { id: 1, category: 'medical', title: 'Insulin Supplies', description: 'Requires thermal storage capable insulated bags for transit.', urgent: true, time: 25, seekerName: 'Dr. Aris Thorne', seekerLocation: 'East Sector Clinic', specifications: 'Cooler volume at least 5 Liters. Must maintain 2-8°C.' },
  { id: 2, category: 'food', title: 'Perishable Rations', description: 'Fresh vegetables and sealed grains for community center.', urgent: false, time: 45, seekerName: 'Maria V.', seekerLocation: 'Downtown Community Kitchen', specifications: 'Needs to be sealed and untouched. Looking for roughly 20 lbs of weight.' },
  { id: 3, category: 'study', title: 'Calculus Textbooks', description: 'For after-school program. Editions from 2018 or newer preferred.', urgent: false, time: 120, seekerName: 'Prof. J. H.', seekerLocation: 'Southside High School', specifications: 'Accepting lightly annotated copies. Must have both Calculus I and II volumes.' },
  { id: 4, category: 'medical', title: 'Bandages & Antiseptics', description: 'Need sterile medical dressings for local clinic.', urgent: true, time: 10, seekerName: 'Westfall Emergency Dept', seekerLocation: 'Westfall Medical', specifications: 'Unopened, standard gauze rolls and 70% isopropyl alcohol.' },
  { id: 5, category: 'clothes', title: 'Winter Coats', description: 'Sizes M and L out of stock at the shelter.', urgent: false, time: 4000, seekerName: 'Salvation Point Shelter', seekerLocation: 'North Ridge', specifications: 'Heavy insulation only. Gently used acceptable.' },
];

const DonorDashboard = ({ onReset }) => {
  const [activeFilter, setActiveFilter] = useState('all');
  const [flowState, setFlowState] = useState(null);
  const [expandedCardData, setExpandedCardData] = useState(null);
  const [rescuedCards, setRescuedCards] = useState({});

  const filteredNeeds = activeFilter === 'all' 
    ? MOCK_NEEDS 
    : MOCK_NEEDS.filter(item => item.category === activeFilter);

  const handleRescue = (id, burnIntensity) => {
    setRescuedCards(prev => ({ ...prev, [id]: burnIntensity }));
    setExpandedCardData(null);
  };

  return (
    <div className="flex flex-col min-h-screen relative isolate">
      <div className="sticky top-0 z-50 bg-paper/80 backdrop-blur-md border-b border-sage/20 px-8 py-4 flex items-center justify-between">
        <h2 className="text-2xl font-serif text-sage tracking-tight">Ecosystem Needs</h2>
        <button onClick={onReset} className="flex items-center gap-2 text-ink-light hover:text-ink transition-colors">
          <span className="text-sm uppercase tracking-widest font-medium">Reset Identity</span>
          <LogOut className="w-4 h-4" />
        </button>
      </div>
      
      <InkTrapFilters activeFilter={activeFilter} onFilterChange={setActiveFilter} />
      
      <div className="flex-1 overflow-y-auto px-4 md:px-8 pb-32">
        <DiscoveryMatrix 
          items={filteredNeeds} 
          renderSubComponent={(item) => (
            <NeedCard 
               title={item.title} 
               description={item.description} 
               urgent={item.urgent} 
               initialTimeSeconds={item.time}
               isRescued={rescuedCards[item.id] !== undefined}
               frozenBurnIntensity={rescuedCards[item.id]}
               onClick={(timeLeft, burnIntensity) => setExpandedCardData({ ...item, timeLeft, burnIntensity })}
            />
          )}
        />
      </div>

      <FloatingAction colorClass="bg-sage" onClick={() => setFlowState('camera')} />

      <AnimatePresence>
        {flowState === 'camera' && (
          <WatercolorCamera colorClass="bg-sage" onSnap={(img) => setFlowState('sundial')} onClose={() => setFlowState(null)} />
        )}
        
        {flowState === 'sundial' && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-paper/90 backdrop-blur-md flex items-center justify-center p-8"
          >
            <div className="absolute top-8 right-8">
               <button onClick={() => setFlowState(null)} className="text-ink-light tracking-widest text-sm uppercase">Close</button>
            </div>
            <SundialPicker colorClass="stroke-sage" onSave={() => setFlowState(null)} />
          </motion.div>
        )}

        {expandedCardData && (
          <ExpandedCardOverlay 
            key="expandedItem"
            layoutId={expandedCardData.title}
            item={expandedCardData}
            onClose={() => setExpandedCardData(null)}
            actionLabel="Commit to Fulfill"
            colorClass="bg-sage"
            title={expandedCardData.title}
            category={expandedCardData.category}
            description={expandedCardData.description}
            specifications={expandedCardData.specifications}
            seekerName={expandedCardData.seekerName}
            seekerLocation={expandedCardData.seekerLocation}
            timeDesc="Verified request timeline active."
            isExpired={expandedCardData.timeLeft <= 0}
            isRescued={rescuedCards[expandedCardData.id] !== undefined}
            onRescue={() => handleRescue(expandedCardData.id, expandedCardData.burnIntensity)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default DonorDashboard;
