import React from 'react';
import { motion } from 'framer-motion';

const OrganicCard = ({ title, children, delay = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        delay, 
        duration: 0.8, 
        type: 'spring', 
        stiffness: 70 
      }}
      whileHover={{ y: -8, transition: { duration: 0.4, ease: 'easeOut' } }}
      className="bg-paper-light p-8 md:p-12 torn-edge shadow-soft relative overflow-hidden"
    >
      <div className="relative z-10">
        <h3 className="text-2xl font-serif text-ink mb-4 font-medium tracking-tight">
          {title}
        </h3>
        <div className="text-ink-light leading-relaxed">
          {children}
        </div>
      </div>
      
      {/* Decorative organic shapes */}
      <motion.div 
        className="absolute -top-10 -right-10 w-32 h-32 bg-paper-dark organic-shape opacity-30 pointer-events-none"
        animate={{ rotate: 360 }}
        transition={{ duration: 40, repeat: Infinity, ease: 'linear' }}
      />
    </motion.div>
  );
};

export default OrganicCard;
