import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const DiscoveryMatrix = ({ items, renderSubComponent }) => {
  return (
    <div className="columns-1 md:columns-2 lg:columns-3 gap-8 py-8 w-full">
      <AnimatePresence>
        {items.map((item) => (
          <motion.div
            key={item.id}
            layout
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, filter: 'blur(4px)' }}
            transition={{ type: 'spring', damping: 20, stiffness: 100 }}
            className="break-inside-avoid mb-8"
          >
            {renderSubComponent(item)}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};

export default DiscoveryMatrix;
