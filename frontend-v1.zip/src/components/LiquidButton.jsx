import React from 'react';
import { motion } from 'framer-motion';

const LiquidButton = ({ children, onClick }) => {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="relative px-8 py-4 bg-ink text-paper rounded-[40px] overflow-hidden group border-none shadow-soft focus:outline-none"
    >
      <span className="relative z-10 font-medium tracking-wide">
        {children}
      </span>
      {/* Liquid hover effect layer */}
      <motion.div 
        className="absolute inset-0 bg-ink-light rounded-[40px] z-0 transform translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out"
        style={{ borderRadius: '48% 52% 68% 32% / 42% 41% 59% 58%' }}
      />
    </motion.button>
  );
};

export default LiquidButton;
