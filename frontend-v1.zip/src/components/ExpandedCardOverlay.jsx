import React, { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, MapPin, User, FileText } from 'lucide-react';

const playPaperUnfold = () => {
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const bufferSize = audioCtx.sampleRate * 0.3;
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const output = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) output[i] = Math.random() * 2 - 1;
    const noise = audioCtx.createBufferSource();
    noise.buffer = buffer;
    const filter = audioCtx.createBiquadFilter();
    filter.type = "highpass";
    filter.frequency.value = 1200;
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(audioCtx.destination);
    noise.start();
  } catch(e) {}
};

const playWaterSizzle = () => {
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    
    // 1. Sizzle & Splash (Noise)
    const bufferSize = audioCtx.sampleRate * 2.0;
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
        // Brown noise approximation for heavy splash
        data[i] = (Math.random() * 2 - 1) * 0.7; 
    }
    const noise = audioCtx.createBufferSource();
    noise.buffer = buffer;
    
    const bandPass = audioCtx.createBiquadFilter();
    bandPass.type = "bandpass";
    bandPass.frequency.setValueAtTime(2000, audioCtx.currentTime); // Start high (sizzle)
    bandPass.frequency.exponentialRampToValueAtTime(150, audioCtx.currentTime + 0.4); // Drop to splash
    bandPass.Q.value = 0.5;

    const noiseGain = audioCtx.createGain();
    noiseGain.gain.setValueAtTime(0, audioCtx.currentTime);
    noiseGain.gain.linearRampToValueAtTime(0.8, audioCtx.currentTime + 0.1); // Explosive splash
    noiseGain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 1.2);
    
    noise.connect(bandPass);
    bandPass.connect(noiseGain);
    noiseGain.connect(audioCtx.destination);
    noise.start();

    // 2. The 40Hz Subwoofer Thud (Wax Seal/Physical Hit)
    const osc = audioCtx.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(150, audioCtx.currentTime); // Transient hit
    osc.frequency.exponentialRampToValueAtTime(40, audioCtx.currentTime + 0.1); // Plunge to sub 40Hz
    
    const oscGain = audioCtx.createGain();
    oscGain.gain.setValueAtTime(0, audioCtx.currentTime);
    oscGain.gain.setValueAtTime(1.5, audioCtx.currentTime + 0.4); // Thud drops after splash
    oscGain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.9);
    
    osc.connect(oscGain);
    oscGain.connect(audioCtx.destination);
    
    osc.start(audioCtx.currentTime + 0.4); // Delay thud slightly for the wax drop
    osc.stop(audioCtx.currentTime + 1.0);

  } catch(e) {}
};

const ExpandedCardOverlay = ({ item, layoutId, onClose, actionLabel, colorClass, title, category, description, specifications, seekerName, seekerLocation, timeDesc, isExpired, isRescued, onRescue }) => {
  const buttonRef = useRef(null);
  const [isWashing, setIsWashing] = useState(false);
  const [washOrigin, setWashOrigin] = useState({ x: 0, y: 0 });

  useEffect(() => {
    // Play physical paper creasing sound on unfold
    playPaperUnfold();
  }, []);

  const handleAction = (e) => {
    if (isExpired) return;
    if (navigator.vibrate) navigator.vibrate([40, 80, 40]);

    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const clickX = e.clientX || (rect.left + rect.width / 2);
      const clickY = e.clientY || (rect.top + rect.height / 2);

      if (item.urgent) {
        setWashOrigin({ x: clickX, y: clickY });
        setIsWashing(true);
        playWaterSizzle(); // Audio sync
        setTimeout(() => {
          onRescue();
          document.dispatchEvent(new CustomEvent('trigger-gold-thread', { detail: { startRect: rect } }));
        }, 800);
      } else {
        onRescue();
        document.dispatchEvent(new CustomEvent('trigger-gold-thread', { detail: { startRect: rect } }));
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 sm:p-8 isolate pointer-events-auto">
      {/* Hideous realism: Inject SVG filter definition for visceral water dousing */}
      <svg width="0" height="0" className="absolute pointer-events-none">
        <defs>
          <filter id="hyper-water-ripple" x="-20%" y="-20%" width="140%" height="140%">
            <feTurbulence type="fractalNoise" baseFrequency="0.015 0.03" numOctaves="4" result="noise" />
            <feDisplacementMap in="SourceGraphic" in2="noise" scale="150" xChannelSelector="R" yChannelSelector="G" result="displaced" />
            <feGaussianBlur in="displaced" stdDeviation="4" result="blurred" />
            <feColorMatrix in="blurred" type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 25 -10" result="frothyWave" />
            <feDropShadow dx="0" dy="10" stdDeviation="15" floodColor="#040b1e" floodOpacity="0.8" />
          </filter>
        </defs>
      </svg>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-ink/60 backdrop-blur-md z-[-1]"
      />

      <motion.div 
        className="relative w-full max-w-2xl min-h-[400px] flex items-stretch z-30 perspective-[2000px]"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0, y: 30 }}
        transition={{ duration: 0.2 }}
      >
        {/* The 4-Fold Paper Geometry */}
        <div className={`absolute inset-0 z-[-1] pointer-events-none drop-shadow-2xl translate-z-0 ${
          item.urgent ? '' : 'torn-edge'
        }`}>
           {/* Top Left Quadrant (Anchor) */}
           <div className={`absolute top-0 left-0 w-1/2 h-1/2 origin-bottom-right shadow-[inset_-2px_-2px_10px_rgba(0,0,0,0.03)] notebook-quadrant notebook-holes-left ${
             item.urgent ? 'burnt-parchment' : ''
           }`} />
           
           {/* Top Right Quadrant (Folds Open First) */}
           <motion.div 
             className={`absolute top-0 right-0 w-1/2 h-1/2 origin-left shadow-[inset_2px_-2px_10px_rgba(0,0,0,0.03)] notebook-quadrant ${
               item.urgent ? 'burnt-parchment' : ''
             }`}
             initial={{ rotateY: -180 }} animate={{ rotateY: 0 }} transition={{ delay: 0.2, duration: 0.5, ease: "easeOut" }}
             style={{ backfaceVisibility: 'hidden' }}
           >
             {/* Dogeared Fold */}
             <div className="absolute top-0 right-0 w-12 h-12 origin-bottom-left shadow-[-4px_4px_6px_rgba(0,0,0,0.3)] transition-all bg-[#e0e0e0]" style={{ clipPath: 'polygon(0% 100%, 100% 100%, 0% 0%)' }} />
             <div className="absolute top-0 right-0 w-12 h-12 origin-bottom-left bg-[#fcfcfc]" style={{ clipPath: 'polygon(100% 0%, 100% 100%, 0% 0%)' }} />
           </motion.div>

           {/* Bottom Left Quadrant (Drops Down Second) */}
           <motion.div 
             className={`absolute bottom-0 left-0 w-1/2 h-1/2 origin-top shadow-[inset_-2px_2px_10px_rgba(0,0,0,0.03)] notebook-quadrant notebook-holes-left ${
               item.urgent ? 'burnt-parchment' : ''
             }`}
             initial={{ rotateX: 180 }} animate={{ rotateX: 0 }} transition={{ delay: 0.7, duration: 0.5, ease: "easeOut" }}
             style={{ backfaceVisibility: 'hidden' }}
           />

           {/* Bottom Right Quadrant (Unfolds horizontal, then vertical together with adjacent panels) */}
           <motion.div 
             className={`absolute bottom-0 right-0 w-1/2 h-1/2 origin-top-left shadow-[inset_2px_2px_10px_rgba(0,0,0,0.03)] notebook-quadrant ${
               item.urgent ? 'burnt-parchment' : ''
             }`}
             initial={{ rotateX: 180, rotateY: -180 }}
             animate={{ rotateX: 0, rotateY: 0 }}
             transition={{
                rotateY: { delay: 0.2, duration: 0.5, ease: "easeOut" },
                rotateX: { delay: 0.7, duration: 0.5, ease: "easeOut" }
             }}
             style={{ backfaceVisibility: 'hidden' }}
           />
        </div>

        {/* Hyper-visceral Water Extinguish Rescue */}
        {isWashing && (
          <motion.div 
            initial={{ clipPath: `circle(0px at ${washOrigin.x}px ${washOrigin.y}px)`, opacity: 0.95 }}
            animate={{ 
              clipPath: [
                `circle(0px at ${washOrigin.x}px ${washOrigin.y}px)`, 
                `circle(1600px at ${washOrigin.x}px ${washOrigin.y}px)`,
                `circle(1600px at ${washOrigin.x}px ${washOrigin.y}px)`
              ],
              opacity: [0.95, 0.8, 0]
            }}
            transition={{ duration: 1.6, times: [0, 0.6, 1], ease: "easeInOut" }}
            className="absolute inset-[-100px] z-50 pointer-events-none mix-blend-color-burn bg-[#0a1636]"
            style={{ filter: "url(#hyper-water-ripple) drop-shadow(0 0 30px rgba(4,10,30,0.8))" }}
          />
        )}

        {/* Ink Fade-in over unfolded letter */}
        <motion.div 
           className="relative flex flex-col md:flex-row w-full z-10"
           initial={{ opacity: 0, filter: 'blur(5px)' }}
           animate={{ opacity: 1, filter: 'blur(0px)' }}
           transition={{ delay: 1.1, duration: 0.4 }}
        >
          <button onClick={onClose} className="absolute top-4 right-4 z-50 bg-[#eaddb6]/50 rounded-full p-2 text-ink/50 hover:text-ink backdrop-blur-md">
            <X className="w-6 h-6" />
          </button>

          {item.imgUrl && (
            <div className="md:w-1/2 min-h-[200px] h-full relative">
              <img src={item.imgUrl} className="w-full h-full object-cover mix-blend-multiply opacity-90" />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#f4ecd8]/40 md:to-[#f4ecd8]/80" />
            </div>
          )}

          <div className={`flex flex-col flex-1 p-8 relative z-30 ${item.imgUrl ? 'md:w-1/2 -ml-8' : 'w-full'}`}>
            <div className="mb-6 flex-1">
              <span className={`text-xs uppercase tracking-widest px-2 py-1 rounded-sm border mb-4 inline-block ${colorClass.replace('bg-', 'text-')} ${colorClass.replace('bg-', 'border-')}/30 bg-ink/5`}>
                {category}
              </span>
              <h2 className="text-3xl font-serif text-ink tracking-tight mb-4">{title}</h2>
              
              <div className="font-mono text-sm text-ink-light space-y-4 mb-8">
                <p className="leading-relaxed border-l-2 border-ink/10 pl-3">{description}</p>
                {specifications && (
                  <div className="flex gap-3">
                    <FileText className="w-4 h-4 mt-0.5 text-ink/30 shrink-0" />
                    <p>{specifications}</p>
                  </div>
                )}
                <div className="flex gap-4 pt-2">
                  {seekerName && (
                    <div className="flex gap-2 items-center text-ink/60">
                      <User className="w-4 h-4" />
                      <span>{seekerName}</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="bg-[#eadded] border border-ink/5 p-4 rounded-xl flex items-center gap-3 shadow-inner mix-blend-multiply">
                <div className={`p-2 rounded-full ${colorClass}/20 text-ink`}>
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-medium tracking-wide">{seekerLocation || 'Location verified'}</span>
                  {timeDesc && <span className="text-xs text-ink-light">{timeDesc}</span>}
                </div>
              </div>
            </div>

            <button 
              ref={buttonRef}
              onClick={handleAction}
              disabled={isExpired || isRescued}
              className={`w-full py-4 text-center font-serif text-lg tracking-widest rounded-sm transition-all duration-300 relative overflow-hidden ${
                 (isExpired || isRescued)
                   ? 'bg-ink/5 text-ink/50 border border-ink/10 cursor-not-allowed' 
                   : `${colorClass} text-[#f4ecd8] hover:scale-[0.98]`
              }`}
              style={!(isExpired || isRescued) ? { 
                boxShadow: 'inset 0px 6px 12px rgba(0,0,0,0.4), inset 0px -2px 0px rgba(0,0,0,0.1), 0 2px 4px rgba(0,0,0,0.1)',
                filter: 'url(#torn-edge-filter) drop-shadow(0px 2px 2px rgba(0,0,0,0.1))',
                transformStyle: 'preserve-3d'
              } : {}}
            >
              <span className="relative z-10 font-bold">{isRescued ? '● Committed & Locked' : isExpired ? 'Dead Request' : actionLabel}</span>
              {!(isExpired || isRescued) && <div className="absolute inset-0 bg-white/20 opacity-0 hover:opacity-100 transition-opacity" />}
            </button>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default ExpandedCardOverlay;
