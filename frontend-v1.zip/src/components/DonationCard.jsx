import React from 'react';
import { motion } from 'framer-motion';

const DonationCard = ({ title, category, imgUrl, onClick }) => {
  const rotateDeg = (Math.random() * 3) - 1.5;

  return (
    <motion.div 
      layoutId={title}
      onClick={onClick}
      className={`relative bg-paper torn-edge transition-all duration-500 hover:-translate-y-1 block ${onClick ? 'cursor-pointer' : ''}`}
      style={{ 
        rotate: `${rotateDeg}deg`,
        filter: 'drop-shadow(3px 8px 16px rgba(0,0,0,0.2))'
      }}
    >
      <div className="h-48 w-full overflow-hidden">
        <img 
          src={imgUrl} 
          alt={title} 
          className="w-full h-full object-cover mix-blend-multiply opacity-90 transition-transform duration-700 hover:scale-105"
        />
      </div>
      <div className="p-6">
        <div className="mb-2">
          <span className="text-xs uppercase tracking-widest text-sage border border-sage/30 px-2 py-1 rounded-sm bg-sage/5">
            {category}
          </span>
        </div>
        <h3 className="text-lg font-serif text-ink tracking-tight">{title}</h3>
        <p className="text-sm text-ink-light mt-2 pb-2">Verified donor. Available for immediate pickup.</p>
      </div>
    </motion.div>
  );
};

export default DonationCard;
