import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const Blob = ({ colorClass, label, colorHex, onSelect, triggerHaptic }) => {
  const ref = useRef(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handlePointerMove = (e) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const distanceX = e.clientX - centerX;
    const distanceY = e.clientY - centerY;
    const maxDist = 150;
    const dist = Math.sqrt(distanceX * distanceX + distanceY * distanceY);
    
    if (dist < maxDist) {
      const pullStrength = 0.3;
      setPosition({ x: distanceX * pullStrength, y: distanceY * pullStrength });
      setIsHovered(true);
    } else {
      setPosition({ x: 0, y: 0 });
      setIsHovered(false);
    }
  };

  const handlePointerLeave = () => {
    setPosition({ x: 0, y: 0 });
    setIsHovered(false);
  };

  const handleClick = () => {
    if (navigator.vibrate) {
      try { navigator.vibrate([30, 50, 30]); } catch(e) {}
    }
    triggerHaptic();
    onSelect({ colorClass, label, colorHex });
  };

  return (
    <motion.div
      ref={ref}
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
      onClick={handleClick}
      animate={{ x: position.x, y: position.y, scale: isHovered ? 1.05 : 1 }}
      whileTap={{ scale: 0.85 }}
      transition={{ type: 'spring', stiffness: 150, damping: 15, mass: 0.5 }}
      className="relative flex items-center justify-center p-8 cursor-pointer z-10"
    >
      <motion.div 
        className={`w-32 h-32 ${colorClass} organic-shape opacity-80 mix-blend-multiply`}
        animate={{
          rotate: [0, 90, 180, 270, 360],
          scale: [1, 1.05, 0.95, 1.05, 1]
        }}
        transition={{ duration: 15 + Math.random() * 5, repeat: Infinity, ease: "linear" }}
      />
      <span className="absolute font-serif text-paper tracking-widest text-lg z-10 drop-shadow-md pointer-events-none mix-blend-overlay opacity-90">
        {label}
      </span>
    </motion.div>
  );
};

const IdentityShifter = ({ onTransitionComplete }) => {
  const [activeBlob, setActiveBlob] = useState(null);
  const [hapticShake, setHapticShake] = useState(0);

  const triggerHaptic = () => setHapticShake(prev => prev + 1);

  const blobs = [
    { id: 'give', colorClass: 'bg-sage', colorHex: '#96a992', label: 'Give' },
    { id: 'seek', colorClass: 'bg-terracotta', colorHex: '#d27d67', label: 'Seek' },
    { id: 'move', colorClass: 'bg-indigo', colorHex: '#4d587a', label: 'Move' },
  ];

  const handleBlobSelect = (blob) => {
    setActiveBlob(blob);
    // Determine which full blob data corresponds
    const fullBlob = blobs.find(b => b.label === blob.label);
    
    // Wait for the bleed animation to fill the screen (1.5s), then notify parent
    setTimeout(() => {
      onTransitionComplete(fullBlob);
    }, 1500); 
  };

  return (
    <motion.div 
      key={hapticShake}
      animate={{ x: [0, -4, 4, -2, 2, 0], y: [0, 2, -2, 1, -1, 0] }}
      transition={{ duration: 0.25, ease: "easeInOut" }}
      className="relative w-full h-[60vh] flex items-center justify-center overflow-visible isolate"
    >
      <div className="flex flex-col md:flex-row gap-12 md:gap-24 items-center justify-center z-10 relative">
        {blobs.map((blob) => (
          <Blob key={blob.id} {...blob} onSelect={handleBlobSelect} triggerHaptic={triggerHaptic} />
        ))}
      </div>

      <AnimatePresence>
        {activeBlob && (
          <motion.div
            key={activeBlob.label}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 100, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className={`fixed z-[100] w-[10vw] h-[10vw] rounded-full ${activeBlob.colorClass} mix-blend-multiply`}
            style={{ top: '50%', left: '50%', margin: '-5vw 0 0 -5vw' }}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default IdentityShifter;
