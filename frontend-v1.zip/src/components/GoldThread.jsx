import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const GoldThread = ({ targetSelectorId = 'user-profile-icon' }) => {
  const [threadPath, setThreadPath] = useState(null);

  useEffect(() => {
    const handleTrigger = (e) => {
      const { startRect } = e.detail;
      const targetEl = document.getElementById(targetSelectorId);
      if (!targetEl) return;
      
      const targetRect = targetEl.getBoundingClientRect();
      
      // Calculate connection coordinates
      const startX = startRect.left + startRect.width / 2;
      const startY = startRect.top + startRect.height;
      const endX = targetRect.left + targetRect.width / 2;
      const endY = targetRect.top;
      
      // Calculate Bezier curve points mapping liquid gravity drop down and across
      const cx1 = startX;
      const cy1 = startY + (endY - startY) * 0.7; // dip heavily before moving over
      const cx2 = endX;
      const cy2 = startY + (endY - startY) * 0.3; // rise to meet target

      const d = `M ${startX} ${startY} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${endX} ${endY}`;
      setThreadPath(d);
      
      // Clear thread after animation completes
      setTimeout(() => {
        setThreadPath(null);
        // Play magnetic click sound + hardware snap vibration
        try {
          const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
          const osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(800, audioCtx.currentTime);
          osc.frequency.exponentialRampToValueAtTime(1200, audioCtx.currentTime + 0.1);
          gain.gain.setValueAtTime(0.5, audioCtx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          osc.start();
          osc.stop(audioCtx.currentTime + 0.1);
          if (navigator.vibrate) navigator.vibrate([10, 30, 20]);
        } catch(err) {}
      }, 800);
    };

    document.addEventListener('trigger-gold-thread', handleTrigger);
    return () => document.removeEventListener('trigger-gold-thread', handleTrigger);
  }, [targetSelectorId]);

  return (
    <AnimatePresence>
      {threadPath && (
        <svg className="fixed inset-0 w-full h-full pointer-events-none z-[110]" style={{ filter: 'drop-shadow(0 0 12px rgba(255,215,0,0.8))' }}>
          <defs>
            <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fff7d6" />
              <stop offset="50%" stopColor="#ffd700" />
              <stop offset="100%" stopColor="#b8860b" />
            </linearGradient>
          </defs>
          <motion.path 
            d={threadPath}
            fill="none"
            stroke="url(#goldGradient)"
            strokeWidth="6"
            strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 1 }}
            animate={{ pathLength: 1, opacity: [1, 1, 0] }}
            transition={{ 
              pathLength: { duration: 0.8, ease: "easeIn" },
              opacity: { times: [0, 0.8, 1], duration: 1 } 
            }}
          />
        </svg>
      )}
    </AnimatePresence>
  );
};

export default GoldThread;
