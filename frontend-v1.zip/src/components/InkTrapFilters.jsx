import React, { useState } from 'react';
import { motion } from 'framer-motion';

const FILTERS = [
  { id: 'all', label: 'All', color: 'bg-ink' },
  { id: 'medical', label: 'Medical', color: 'bg-blue-600' },
  { id: 'food', label: 'Food', color: 'bg-orange-500' },
  { id: 'study', label: 'Study', color: 'bg-green-600' },
  { id: 'clothes', label: 'Clothes', color: 'bg-purple-500' },
];

const InkTrapFilters = ({ activeFilter, onFilterChange }) => {
  return (
    <div className="sticky top-0 z-40 bg-transparent backdrop-blur-md border-b flex gap-6 px-8 py-4 border-ink/10 overflow-x-auto no-scrollbar mask-linear-fade">
      {FILTERS.map(filter => {
        const isActive = activeFilter === filter.id;
        return (
          <button
            key={filter.id}
            onClick={() => onFilterChange(filter.id)}
            className={`relative px-4 py-2 text-sm uppercase tracking-wider font-medium transition-colors ${
              isActive ? 'text-paper' : 'text-ink-light hover:text-ink'
            }`}
          >
            <span className="relative z-10">{filter.label}</span>
            {isActive && (
              <motion.div
                layoutId="inkDrop"
                className={`absolute inset-0 z-0 rounded-full ${filter.color} mix-blend-multiply`}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 0.8, scale: 1 }}
                transition={{ type: 'spring', bounce: 0.4, duration: 0.6 }}
              />
            )}
          </button>
        );
      })}
    </div>
  );
};

export default InkTrapFilters;
