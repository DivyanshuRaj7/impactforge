import React, { useRef, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const WatercolorCamera = ({ onSnap, onClose, colorClass = 'bg-sage' }) => {
  const videoRef = useRef(null);
  const [hasSnapped, setHasSnapped] = useState(false);
  const [hasCameraAccess, setHasCameraAccess] = useState(true);
  const [scanStage, setScanStage] = useState(0);

  // Initialize Native Camera Stream
  useEffect(() => {
    let stream = null;
    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error("Camera access denied or unavailable", err);
        setHasCameraAccess(false);
      }
    };
    startCamera();
    
    // Cleanup track on unmount
    return () => {
      if (stream) stream.getTracks().forEach(t => t.stop());
    };
  }, []);

  const handleSnap = () => {
    if(hasSnapped) return;
    setHasSnapped(true);
    setScanStage(1);
    
    if (navigator.vibrate) navigator.vibrate([20, 50, 20]);
    
    setTimeout(() => {
      onSnap("fake-blob"); 
    }, 2200); 
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 100 }} 
      animate={{ opacity: 1, y: 0 }} 
      exit={{ opacity: 0, y: 100 }}
      className="fixed inset-0 z-[100] bg-ink flex flex-col"
    >
      <div className="relative flex-1 bg-black overflow-hidden m-4 mt-8 rounded-2xl border border-white/5">
        {!hasCameraAccess && (
          <div className="absolute inset-0 flex items-center justify-center text-paper font-sans text-center p-8 text-opacity-50">
            Hardware camera inaccessible. Simulating Matrix Vibe-Check.
          </div>
        )}
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          className={`w-full h-full object-cover transition-all duration-300 ${hasSnapped ? 'opacity-60 saturate-150 brightness-75' : 'opacity-100'}`}
        />
        
        {/* Sleek Digital Scanner */}
        <AnimatePresence>
          {scanStage === 1 && (
             <motion.div 
               initial={{ top: '0%' }}
               animate={{ top: '100%' }}
               transition={{ duration: 1.8, ease: "linear" }}
               className={`absolute left-0 right-0 z-30 h-0.5 shadow-[0_0_20px_#9cbb04] bg-[#9cbb04]`}
             >
               <div className={`absolute bottom-0 left-0 right-0 h-48 pointer-events-none`} style={{ background: 'linear-gradient(to top, rgba(156, 187, 4, 0.4), transparent)' }} />
             </motion.div>
          )}
        </AnimatePresence>

        {/* Optical Viewfinder Frame */}
        <div className="absolute inset-8 border border-white/20 rounded-xl pointer-events-none transition-opacity duration-500" style={{ opacity: scanStage === 1 ? 0 : 1 }}>
          <div className="absolute top-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
          <div className="absolute bottom-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 pointer-events-none transition-opacity duration-500" style={{ opacity: scanStage === 1 ? 0 : 1 }}>
          <div className="absolute top-0 left-1/2 w-px h-full bg-white/40" />
          <div className="absolute left-0 top-1/2 w-full h-px bg-white/40" />
        </div>
      </div>

      <div className="h-40 bg-zinc-900 border-t border-white/5 flex items-center justify-between px-12 pt-6 pb-12">
        <button onClick={onClose} disabled={scanStage > 0} className={`p-4 text-white hover:opacity-70 transition-opacity ${scanStage > 0 ? 'opacity-20 cursor-not-allowed' : ''}`}>
          <X className="w-8 h-8" />
        </button>
        <button 
          onClick={handleSnap}
          disabled={hasSnapped}
          className={`w-20 h-20 rounded-full border border-white/20 flex items-center justify-center p-1.5 transition-transform active:scale-95 ${hasSnapped ? 'opacity-50 scale-90' : 'opacity-100 hover:border-white/40'}`}
        >
          <div className={`w-full h-full rounded-full ${hasSnapped ? 'animate-pulse' : ''}`} style={{ backgroundColor: '#9cbb04' }} />
        </button>
        <div className="w-16" />
      </div>
    </motion.div>
  );
};

export default WatercolorCamera;
