import React, { useState } from 'react';
import { LogOut } from 'lucide-react';
import InkTrapFilters from './InkTrapFilters';
import DiscoveryMatrix from './DiscoveryMatrix';
import BridgeCard from './BridgeCard';

const MOCK_BRIDGES = [
  { id: 1, category: 'medical', item: 'Insulin Supplies', from: 'Northside Clinic', to: 'Downtown Shelter', estimatedTime: '45 mins' },
  { id: 2, category: 'food', item: 'Canned Goods Bundle', from: 'Community Pantry', to: 'Eastside Youth Center', estimatedTime: '1.5 hrs' },
  { id: 3, category: 'study', item: 'Engineering Textbooks', from: 'University Library', to: 'Public High School', estimatedTime: '2 hrs' },
  { id: 4, category: 'clothes', item: 'Winter Coats', from: 'Suburban Donation Drop', to: 'Downtown Shelter', estimatedTime: '3 hrs' },
];

const MediatorDashboard = ({ onReset }) => {
  const [activeFilter, setActiveFilter] = useState('all');

  const filteredBridges = activeFilter === 'all' 
    ? MOCK_BRIDGES 
    : MOCK_BRIDGES.filter(item => item.category === activeFilter);

  return (
    <div className="flex flex-col min-h-screen">
      <div className="sticky top-0 z-50 bg-paper/80 backdrop-blur-md border-b border-indigo/20 px-8 py-4 flex items-center justify-between">
        <h2 className="text-2xl font-serif text-indigo tracking-tight">Active Logistics</h2>
        <button onClick={onReset} className="flex items-center gap-2 text-ink-light hover:text-ink transition-colors">
          <span className="text-sm uppercase tracking-widest font-medium">Reset Identity</span>
          <LogOut className="w-4 h-4" />
        </button>
      </div>
      
      <InkTrapFilters activeFilter={activeFilter} onFilterChange={setActiveFilter} />
      
      <div className="flex-1 overflow-y-auto px-4 md:px-8">
        <DiscoveryMatrix 
          items={filteredBridges} 
          renderSubComponent={(item) => (
            <BridgeCard from={item.from} to={item.to} item={item.item} estimatedTime={item.estimatedTime} />
          )}
        />
      </div>
    </div>
  );
};

export default MediatorDashboard;
