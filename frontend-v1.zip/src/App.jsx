import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import IdentityShifter from './components/IdentityShifter';
import DonorDashboard from './components/DonorDashboard';
import SeekerDashboard from './components/SeekerDashboard';
import MediatorDashboard from './components/MediatorDashboard';
import GoldThread from './components/GoldThread';

const ROLE_TINTS = {
  give: 'bg-sage/40',
  seek: 'bg-terracotta/40',
  move: 'bg-indigo/40'
};

function App() {
  const [activeRole, setActiveRole] = useState(null);

  // Called by IdentityShifter *after* the bleed animation completes
  const handleRoleTransition = (roleData) => {
    setActiveRole(roleData.id);
  };

  const handleReset = () => {
    setActiveRole(null);
  };

  return (
    <div className={`noise-bg text-ink selection:bg-ink selection:text-paper transition-colors duration-1000 ${
      activeRole ? ROLE_TINTS[activeRole] : 'bg-paper'
    } ${!activeRole ? 'h-screen overflow-hidden' : 'min-h-screen'}`}>
      
      <AnimatePresence mode="wait">
        {!activeRole ? (
          <motion.div 
            key="landing"
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="w-full h-full flex flex-col items-center justify-center relative p-6"
          >
            {/* Landing page logic ... */}
            <header className="absolute top-16 text-center max-w-2xl z-10 pointer-events-none">
              <motion.h1 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-4xl md:text-5xl font-serif tracking-tight leading-[1.1] mb-4 font-light"
              >
                Find your place within <br/> 
                <span className="italic font-medium">the ecosystem</span>.
              </motion.h1>
            </header>
            
            <div className="w-full h-full flex items-center justify-center mt-20 z-20">
              <IdentityShifter onTransitionComplete={handleRoleTransition} />
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className="w-full min-h-screen relative"
          >
            {activeRole === 'give' && <DonorDashboard onReset={handleReset} />}
            {activeRole === 'seek' && <SeekerDashboard onReset={handleReset} />}
            {activeRole === 'move' && <MediatorDashboard onReset={handleReset} />}
            
            {/* Global Target Anchor for Gold Thread Animations */}
            <div 
              id="user-profile-icon" 
              className="fixed bottom-8 left-8 z-[60] w-16 h-16 rounded-full bg-paper shadow-soft torn-edge flex items-center justify-center overflow-hidden"
              style={{ filter: "drop-shadow(2px 4px 8px rgba(0,0,0,0.1))" }}
            >
               <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&q=80" className="w-full h-full object-cover mix-blend-multiply opacity-80" />
            </div>
            
            <GoldThread targetSelectorId="user-profile-icon" />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
