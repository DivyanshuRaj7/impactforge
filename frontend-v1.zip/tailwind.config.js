/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        paper: {
          DEFAULT: '#f4f1eb', 
          dark: '#e6dfd1',    
          light: '#fdfbfa',   
        },
        ink: {
          DEFAULT: '#2b2a27', 
          light: '#4a4843',   
        },
        sage: '#96a992',
        terracotta: '#d27d67',
        indigo: '#4d587a'
      },
      boxShadow: {
        'soft': '0 10px 40px -10px rgba(43, 42, 39, 0.08)',
        'inner-soft': 'inset 0 2px 10px rgba(0, 0, 0, 0.03)',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
